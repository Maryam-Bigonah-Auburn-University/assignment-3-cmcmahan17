#include <iostream>
#include "Question_1.cpp"
#include "Question_2.cpp"
#include "Question_3.cpp"
#include "Header1.h"
using namespace std;
int checkAvailable(char seatChart[7][5], int row, char seat);
void printSeats(char seatsAvailable[7][5]);
int main()
{
	cout << "Question 1:\n";
	Answer_1();

	cout << "\n \nQuestion 2:\n";
	Answer_2();

	// Not gonna lie I hit a road block looking at this and I don't have the energy or effort to get over it.

	//cout << "\n \nQuestion 3:\n";
	//Answer_3();

	return 0;
}