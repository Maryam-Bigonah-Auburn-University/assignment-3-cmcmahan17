#pragma once
#include <iostream>
using namespace std;
int checkAvailable(char seatChart[7][5], int row, char seat)
{
	while (row < 1 || row > 7)
	{
		cout << "\n" << row << " is not a valid row. Please choose a row between 1 and 7." << endl;
		cout << "Enter a row: ";
		cin >> row;
		cout << "Enter a seat: ";
		cin >> seat;
	}

	// row passed to index 4 elements at most
	int isThere = 0;
	row -= 1;
	for (int i = 1; i < 5; i++)
	{
		if (seatChart[row][i] == seat)
		{
			seatChart[row][i] = 'X';
			isThere = 1;
		}
	}
	return isThere;
}

// Print every element in the matrix
void printSeats(char seatChart[7][5])
{
	cout << "\nAVAILABLE SEATS:" << endl;
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			cout << seatChart[i][j] << " ";
		}
		cout << endl;
	}
}