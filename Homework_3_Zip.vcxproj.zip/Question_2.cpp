#include <iostream>
using namespace std;

int checkAvailable(char seatChart[7][5], int row, char seat);
void printSeats(char seatsAvailable[7][5]);

// The code is structured so that you input the row number and the seat letter separately
// Yet somehow if you did both in the first line then it still works (e.g. 3C)

static int Answer_2()
{
	int seatsAvailable = 28;
	int row;
	int isOpen;
	char seat;
	char done = 'f'; // Placeholder text
	char seatChart[7][5] = { {'1','A','B','C','D'},
							 {'2','A','B','C','D'},
							 {'3','A','B','C','D'},
							 {'4','A','B','C','D'},
							 {'5','A','B','C','D'},
							 {'6','A','B','C','D'},
							 {'7','A','B','C','D'} };

	do
	{
		printSeats(seatChart);
		cout << "\nEnter a row: ";
		cin >> row;

		cout << "Enter a seat: ";
		cin >> seat;
		
		// Running a counter instead since I think it is easier
		isOpen = checkAvailable(seatChart, row, seat);
		if (isOpen == 1)
		{
			seatsAvailable -= 1;
		}
		else
		{
			while (isOpen == 0) 
			{
				cout << "Seat is not available. Please choose another seat.\n"
					<< "Enter a row: ";
				cin >> row;

				cout << "Enter a seat: ";
				cin >> seat;
				isOpen = checkAvailable(seatChart, row, seat);
			}
		}

		if (seatsAvailable > 0)
		{
			cout << "\nWould you like to book another seat?\n"
				<< "Enter 'Y' to continue or press any to key and hit Enter to exit: ";
			cin >> done;
		}
	}while (done == 'Y' && seatsAvailable > 0);
	
	if (seatsAvailable == 0)
	{
		cout << "All seats booked";
	}

	return 0;
}

/*int checkAvailable(char seatChart[7][5], int row, char seat)
{
	while (row < 1 || row > 7)
	{
		cout << "\n" << row << " is not a valid row. Please choose a row between 1 and 7." << endl;
		cout << "Enter a row: ";
		cin >> row;
		cout << "Enter a seat: ";
		cin >> seat;
	}

	// row passed to index 4 elements at most
	int isThere = 0;
	row -= 1;
	for (int i = 1; i < 5; i++)
	{
		if (seatChart[row][i] == seat)
		{
			seatChart[row][i] = 'X';
			isThere = 1;
		}
	}
	return isThere;
}

// Print every element in the matrix
void printSeats(char seatChart[7][5])
{
	cout << "\nAVAILABLE SEATS:" << endl;
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			cout << seatChart[i][j] << " ";
		}
		cout << endl;
	}
}
*/