#include <iostream>
#include <string>
using namespace std;

static int Answer_1()
{
	string string1, string2;
	int x[20] = {0}, y[20] = {0}, sum[20] = {0};
	int SL1; //Length of string 1
	int SL2; //Length of string 2

	//Making sure the number isn't too large
	cout << "Enter two positive integers up to 20 digits long to be summed." << endl;
	do
	{
		cout << "Integer 1: ";
		cin >> string1;
		SL1 = string1.length() - 1;
		if (SL1 > 19)
		{
			cout << "\nInteger 1 is too long. Please remove " << (SL1 - 19) << " digits." << endl;
		}
	} while (SL1 > 19);

	do
	{
		cout << "Integer 2: ";
		cin >> string2;
		SL2 = string2.length() - 1;
		if (SL2 > 19)
		{
			cout << "\nInteger 2 is too long. Please remove " << (SL2 - 19) << " digits." << endl;
		}
	} while (SL2 > 19);
	
	//To keep the arrays in line while going through the loop since
	int gap1 = 19 - SL1;
	int gap2 = 19 - SL2;
	int adjusted;
	int num;
	
	//Translating
	for (int i = SL1; i > -1; i--)
	{
		num = string1[i]-48;
		adjusted = i + gap1;
		x[adjusted] = num;
	}
	
	for (int i = SL2; i > -1; i--)
	{
		num = string2[i] - 48;
		adjusted = i + gap2;
		y[adjusted] = num;
	}
	
	//Addition time
	int bonus = 0;
	int z;
	for (int i = 19; i > -1; i--)
	{
		z = x[i] + y[i] + bonus;
		if (z > 9)
		{
			sum[i] = (z-10);
			bonus = 1;
		}
		else
		{
			sum[i] = z;
			bonus = 0;
		}
	}

	//Print results
	cout << "Sum: " << endl;
	for (int i = 0; i < 20; i++)
	{
		cout << sum[i];
	}

	return 0;
}
