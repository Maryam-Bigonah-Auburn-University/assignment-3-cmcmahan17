#include <iostream>
#include <iomanip>
using namespace std;

static int Answer_3()
{

	cout << "Enter array stuff";
	

	return 0;
}